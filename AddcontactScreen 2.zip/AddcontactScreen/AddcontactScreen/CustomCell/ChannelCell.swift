//
//  ChannelCell.swift
//  AddcontactScreen
//
//  Created by Liem Pham on 5/16/19.
//  Copyright © 2019 Doodo. All rights reserved.
//

import UIKit
class ChannelCell:BaseTableCell {
    lazy var profileImageView : UIImageView = {
        let profileImage = UIImageView()
        profileImage.image = #imageLiteral(resourceName: "selena")
        profileImage.contentMode = .scaleToFill
        profileImage.layer.cornerRadius = 10
        profileImage.layer.masksToBounds = true
        return profileImage
    }()
    lazy var channelTitle:UILabel = {
        let channeltitle = UILabel()
        channeltitle.text = "SelenaVEVO"
        channeltitle.textAlignment = .left
        channeltitle.font = UIFont.systemFont(ofSize: 14, weight: UIFont.Weight.medium)
        return channeltitle
    }()
    lazy var subtitle :UILabel = {
        let channelSubtitle = UILabel()
        channelSubtitle.text = "489K subcribers"
        channelSubtitle.textAlignment = .left
        channelSubtitle.font = UIFont.systemFont(ofSize: 11, weight: .light)
        return channelSubtitle
    }()
    
    
    
    override func setupCustomCell() {
        self.addSubview(profileImageView)
      //  self.addSubview(channelTitle)
      //  self.addSubview(subtitle)
        
        addConstraintsWithFormat("H:|-16-[v0(30)]", views: profileImageView)
        addConstraintsWithFormat("V:|-8-[v0]-8-|", views: profileImageView)
    }
}
