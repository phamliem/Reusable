//
//  CustomTitleCell.swift
//  AddcontactScreen
//
//  Created by Liem Pham on 5/16/19.
//  Copyright © 2019 Doodo. All rights reserved.
//

import UIKit
class BaseTableCell :UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        setupCustomCell()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setupCustomCell(){
        
    }
    
}

class CustomTitleCell:BaseTableCell {
    
    lazy var  videoTitle :UILabel = {
        let videotitle = UILabel()
        //videotitle.translatesAutoresizingMaskIntoConstraints = false
        videotitle.font = UIFont.systemFont(ofSize: 18)
        return videotitle
    }()
    
    lazy var numberofViews:UILabel = {
        
        let numberofviews = UILabel()
        //numberofviews.translatesAutoresizingMaskIntoConstraints = false
        numberofviews.font = UIFont.systemFont(ofSize: 13, weight: .light)
        //numberofviews.backgroundColor = .green
        return numberofviews
    }()
    lazy var likeButton :CustomButton = {
        let likebutton = CustomButton()
        likebutton.buttonImageView.image = #imageLiteral(resourceName: "like")
        likebutton.buttonTitle.text = "89.6K"
        likebutton.buttonTitle.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.light)
        return likebutton
    }()
    lazy var dislikeButton:CustomButton = {
        let dislikebutton = CustomButton()
        dislikebutton.buttonImageView.image = #imageLiteral(resourceName: "dislike")
        dislikebutton.buttonTitle.text = "12.1K"
        dislikebutton.buttonTitle.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return dislikebutton
    }()
    lazy var shareButton:CustomButton = {
        let sharebutton = CustomButton()
        sharebutton.buttonImageView.image = #imageLiteral(resourceName: "share")
        sharebutton.buttonTitle.text = "Share"
        sharebutton.buttonTitle.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return sharebutton
    }()
    lazy var downloadButton :CustomButton = {
        let downloadbutton = CustomButton()
        downloadbutton.buttonImageView.image = #imageLiteral(resourceName: "download")
        downloadbutton.buttonTitle.text = "Download"
        downloadbutton.buttonTitle.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return downloadbutton
    }()
    lazy var saveButton :CustomButton =  {
        let savebutton = CustomButton()
        savebutton.buttonImageView.image = #imageLiteral(resourceName: "add to")
        savebutton.buttonTitle.text = "Save"
        savebutton.buttonTitle.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return savebutton
    }()
    
    
    
    
    override func  setupCustomCell() {
        self.addSubview(videoTitle)
        self.addSubview(numberofViews)
        self.addSubview(likeButton)
        self.addSubview(dislikeButton)
        self.addSubview(shareButton)
        self.addSubview(downloadButton)
        self.addSubview(saveButton)
        
        addConstraintsWithFormat("H:|-12-[v0]-0-|", views: videoTitle)
        addConstraintsWithFormat("H:|-12-[v0(140)]", views: numberofViews)
        addConstraintsWithFormat("V:|-0-[v0(40)]-0-[v1(20)]", views: videoTitle, numberofViews)
        
        addConstraint(NSLayoutConstraint(item: numberofViews, attribute: .top, relatedBy: .equal, toItem: videoTitle, attribute: .bottom, multiplier: 1, constant: 0))
        
        //like button
        addConstraintsWithFormat("H:|-32-[v0(36)]-32-[v1(36)]-32-[v2(36)]-32-[v3(60)]-32-[v4]-32-|", views: likeButton, dislikeButton , shareButton , downloadButton , saveButton)
        addConstraintsWithFormat("V:[v0]-16-[v1]-16-|", views: numberofViews , likeButton)
        
        //dislike button
        addConstraint(NSLayoutConstraint(item: dislikeButton, attribute: .top, relatedBy: .equal, toItem: numberofViews, attribute: .bottom, multiplier: 1, constant: 16))
        addConstraint(NSLayoutConstraint(item: dislikeButton, attribute: .bottom, relatedBy: .equal, toItem: likeButton, attribute: .bottom, multiplier: 1, constant: 0))
        
        //share button
        addConstraint(NSLayoutConstraint(item: shareButton, attribute: .top, relatedBy: .equal, toItem: dislikeButton, attribute: .top, multiplier: 1, constant: 0))
        addConstraint(NSLayoutConstraint(item: shareButton, attribute: .bottom, relatedBy: .equal, toItem: dislikeButton, attribute: .bottom, multiplier: 1, constant: 0))
        
        //download button
        addConstraint(NSLayoutConstraint(item: downloadButton, attribute: .top, relatedBy: .equal, toItem: shareButton, attribute: .top, multiplier: 1, constant: 0))
        addConstraint(NSLayoutConstraint(item: downloadButton, attribute: .bottom, relatedBy: .equal, toItem: shareButton, attribute: .bottom, multiplier: 1, constant: 0))
        
        //save button
        addConstraint(NSLayoutConstraint(item: saveButton, attribute: .top, relatedBy: .equal, toItem: downloadButton, attribute: .top, multiplier: 1, constant: 0))
        addConstraint(NSLayoutConstraint(item: saveButton, attribute: .bottom, relatedBy: .equal, toItem: downloadButton, attribute: .bottom, multiplier: 1, constant: 0))
        
        
        
    }
}


class CustomButton:UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupButton()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var buttonImageView :UIImageView = {
        let buttonImageview = UIImageView()
        buttonImageview.contentMode = .scaleAspectFit
        buttonImageview.layer.masksToBounds = true
        buttonImageview.layer.cornerRadius = 10
        return buttonImageview
    }()
    lazy var buttonTitle : UILabel = {
        let buttontitle = UILabel()
        buttontitle.textAlignment = .center
        
        return buttontitle
    }()
    func setupButton(){
        self.addSubview(buttonImageView)
        self.addSubview(buttonTitle)
        addConstraintsWithFormat("H:|-0-[v0]-0-|", views: buttonTitle)
        addConstraintsWithFormat("H:|-0-[v0]-0-|", views: buttonImageView)
        addConstraintsWithFormat("V:|-0-[v0(32)]-4-[v1]-0-|", views: buttonImageView , buttonTitle)
        addConstraint(NSLayoutConstraint(item: buttonImageView, attribute: .left, relatedBy: .equal, toItem: buttonTitle, attribute: .right, multiplier: 1, constant: 0))
    }
}



