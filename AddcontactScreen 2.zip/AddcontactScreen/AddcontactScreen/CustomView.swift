//
//  Lesson01ViewController.swift
//  Lesson01
//
//  Created by Anh Tai LE on 13/12/2018.
//  Copyright © 2018 iZeta Co. All rights reserved.
//

import UIKit
protocol CustomViewDelegate:NSObjectProtocol {
    func handleForMyButtonPressed(_ contact: ContactModel) -> Void
    func handleForKeyboardWillShow(kbHeight: CGFloat) ->Void
    func handleForKeyboardWillHide() ->Void
    func handleForMyButtonClicked()->Void
}
class CustomView: UIView
{
    var delegate:CustomViewDelegate?
    
    
    fileprivate let screenSize = UIScreen.main.bounds
    
    fileprivate var myLabelName :UILabel = UILabel()
    
    fileprivate var myTextFieldName: UITextField = UITextField()
    
    fileprivate var myLabelPhone :UILabel = UILabel()
    
    fileprivate var myTextFieldPhone: UITextField = UITextField()
    
    fileprivate var myLabelEmail :UILabel = UILabel()
    
    fileprivate var myTextFieldEmail:UITextField = UITextField()
    
    fileprivate var myLabelCompany :UILabel = UILabel()
    
    fileprivate var myTextFieldCompany:UITextField = UITextField()
    
    fileprivate var myLabelWeb : UILabel = UILabel()
    
    fileprivate var myTextFieldWeb : UITextField = UITextField ()
    
    fileprivate var myButton: UIButton = UIButton(type: .custom)
    
    
    
    fileprivate var wasSettedUpUI: Bool = false
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        if !wasSettedUpUI {
            wasSettedUpUI = true
            
            setupUI()
            }
    }
    func setupUI() {

        
        
        
        

        //name label
        
        myLabelName.text = String("name")
        myLabelName.translatesAutoresizingMaskIntoConstraints = false
        myLabelName.textAlignment = .left
        myLabelName.backgroundColor = .blue
        myLabelName.textColor = .white
        myLabelName.font = UIFont.boldSystemFont(ofSize: 20)
        self.addSubview(myLabelName)
       
        //name text field
        myTextFieldName.placeholder = "input full name"
        myTextFieldName.translatesAutoresizingMaskIntoConstraints = false
        myTextFieldName.textAlignment = .left
        myTextFieldName.textColor = UIColor.black
        myTextFieldName.backgroundColor = UIColor.white
        myTextFieldName.clearButtonMode = .whileEditing
        myTextFieldName.delegate = self
        self.addSubview(myTextFieldName)
        
        //phone label
        myLabelPhone.text = "phone"
        myLabelPhone.translatesAutoresizingMaskIntoConstraints = false
        myLabelPhone.textAlignment = .left
        myLabelPhone.backgroundColor = .blue
        myLabelPhone.textColor = .white
        myLabelPhone.font = UIFont.boldSystemFont(ofSize: 20)
        self.addSubview(myLabelPhone)
        
        //phone text field
        myTextFieldPhone.placeholder = "ur phone number"
        myTextFieldPhone.textAlignment = .left
        myTextFieldPhone.translatesAutoresizingMaskIntoConstraints = false
        myTextFieldPhone.textColor = UIColor.black
        myTextFieldPhone.backgroundColor = UIColor(red: 246.0/255.0, green: 246.0/255.0, blue: 246.0/255.0, alpha: 1.0)
        myTextFieldPhone.clearButtonMode = .whileEditing
        myTextFieldPhone.delegate = self
        self.addSubview(myTextFieldPhone)
        
        //email label
        myLabelEmail.text = "Email"
        myLabelEmail.textAlignment = .left
        myLabelEmail.backgroundColor = .blue
        myLabelEmail.translatesAutoresizingMaskIntoConstraints = false
        myLabelEmail.textColor = .white
        myLabelEmail.font = UIFont.boldSystemFont(ofSize: 20)
        self.addSubview(myLabelEmail)
        
        //email text field
        myTextFieldEmail.translatesAutoresizingMaskIntoConstraints = false
        myTextFieldEmail.placeholder = "ur email"
        myTextFieldEmail.textAlignment = .left
        myTextFieldEmail.textColor = UIColor.black
        myTextFieldEmail.backgroundColor = UIColor(red: 246.0/255.0, green: 246.0/255.0, blue: 246.0/255.0, alpha: 1.0)
        myTextFieldEmail.clearButtonMode = .whileEditing
        myTextFieldEmail.delegate = self
        self.addSubview(myTextFieldEmail)
        
        //company label
        myLabelCompany.translatesAutoresizingMaskIntoConstraints = false
        myLabelCompany.text = "company"
        myLabelCompany.textAlignment = .left
        myLabelCompany.backgroundColor = .blue
        myLabelCompany.textColor = .white
        myLabelCompany.font = UIFont.boldSystemFont(ofSize: 20)
        self.addSubview(myLabelCompany)
        
        //company text field
        myTextFieldCompany.translatesAutoresizingMaskIntoConstraints = false
        myTextFieldCompany.placeholder = "ur company name"
        myTextFieldCompany.textAlignment = .left
        myTextFieldCompany.textColor = UIColor.black
        myTextFieldCompany.backgroundColor = UIColor(red: 246.0/255.0, green: 246.0/255.0, blue: 246.0/255.0, alpha: 1.0)
        myTextFieldCompany.clearButtonMode = .whileEditing
        myTextFieldCompany.delegate = self
        self.addSubview(myTextFieldCompany)
        
        //website label
        myLabelWeb.translatesAutoresizingMaskIntoConstraints = false
        myLabelWeb.text = "website"
        myLabelWeb.textAlignment = .left
        myLabelWeb.backgroundColor = .blue
        myLabelWeb.textColor = .white
        myLabelWeb.font = UIFont.boldSystemFont(ofSize: 20)
        self.addSubview(myLabelWeb)
        
        //website text field
        myTextFieldWeb.translatesAutoresizingMaskIntoConstraints = false
        myTextFieldWeb.placeholder = "ur web address"
        myTextFieldWeb.textAlignment = .left
        myTextFieldWeb.textColor = UIColor.black
        myTextFieldWeb.backgroundColor = UIColor(red: 246.0/255.0, green: 246.0/255.0, blue: 246.0/255.0, alpha: 1.0)
        myTextFieldWeb.clearButtonMode = .whileEditing
        myTextFieldWeb.delegate = self
        self.addSubview(myTextFieldWeb)
        //add contact button
        
        
        myButton.translatesAutoresizingMaskIntoConstraints = false
        myButton.setTitle("Add Contact", for: .normal)
        myButton.titleLabel?.textAlignment = .center
        myButton.titleLabel?.textColor = .black
        myButton.backgroundColor = .gray
        myButton.setTitleColor(.darkGray, for: .disabled)
        myButton.setTitleColor(.black, for: .normal)
        myButton.setTitleColor(.yellow, for: .highlighted)
        myButton.addTarget(self, action: #selector(CustomView.handleButtonActionTouchUpInside(_:)), for: .touchUpInside)
        self.addSubview(myButton)
        //back button
        
        let views:[String:UIView] = [
                                     "phonelabel":myLabelPhone,"phoneTF":myTextFieldPhone,
                                     "emaillabel":myLabelEmail,"emailTF":myTextFieldEmail,
                            "companylabel":myLabelCompany,"companyTF":myTextFieldCompany,
                                     "weblabel":myLabelWeb,"webTF":myTextFieldWeb,
                                     "namelabel":myLabelName,"nameTF":myTextFieldName,
                                    "addcontactbutton":myButton]
        //set metrics
        let metrics = ["nortchTop" : self.safeAreaInsets.top ,
                       "nortchBottom" : self.safeAreaInsets.bottom,
                       "nortchLeft" : self.safeAreaInsets.left ,
                       "nortchRight" : self.safeAreaInsets.right,
                       "m20":20,
                       "m30":30,
                       "m60":60]
        //khai bao string cua constraints
        
        //vetical label va vertical constraints
        let VlabelConstraints = "V:|-m20-[namelabel(30)]-m20-[phonelabel(30)]-m20-[emaillabel(30)]-m20-[companylabel(30)]-m20-[weblabel(30)]-m30-[addcontactbutton]"
        
        let VtextfieldConstraints = "V:|-m20-[nameTF(30)]-m20-[phoneTF(30)]-m20-[emailTF(30)]-m20-[companyTF(30)]-m20-[webTF(30)]-m30-[addcontactbutton]"
        //5 cap text field va label
        let HnamelabelAndtextfieldConstraints = "H:|-nortchLeft-[namelabel(90)]-m20-[nameTF]-nortchRight-|"
        
        let HphonelabelAndtextfieldConstraints = "H:|-nortchLeft-[phonelabel(90)]-m20-[phoneTF]-nortchRight-|"
        
        let HemaillabelAndtextfieldConstraints = "H:|-nortchLeft-[emaillabel(90)]-m20-[emailTF]-nortchRight-|"
        
        let HcompanylabelAndtextfieldConstraints = "H:|-nortchLeft-[companylabel(90)]-m20-[companyTF]-nortchRight-|"
        
        let HweblabelAndtextfieldConstraints = "H:|-nortchLeft-[weblabel(90)]-m20-[webTF]-nortchRight-|"
        
        //add contact button
        let VaddcontactbuttonConstraints = "V:[webTF]-m60-[addcontactbutton(50)]"

        let HaddcontactbuttonConstraints = "H:|[addcontactbutton]|"
        
        //goi tat ca constraints vao
        var constraints:[NSLayoutConstraint] = []
        //vertical label va vertical textfield
        
        constraints += NSLayoutConstraint.constraints(withVisualFormat: VlabelConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: VtextfieldConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
        
        //5 cap label va text field
        
        constraints += NSLayoutConstraint.constraints(withVisualFormat: HnamelabelAndtextfieldConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: HphonelabelAndtextfieldConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: HemaillabelAndtextfieldConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: HcompanylabelAndtextfieldConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: HweblabelAndtextfieldConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
      
        //add contact button
         constraints += NSLayoutConstraint.constraints(withVisualFormat: VaddcontactbuttonConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
         constraints += NSLayoutConstraint.constraints(withVisualFormat: HaddcontactbuttonConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
        //activate het tat ca
        NSLayoutConstraint.activate(constraints)
        
    }

    
    @objc func handleButtonActionTouchDown(_ sender:Any)
    {
        print("LOL")
        delegate?.handleForMyButtonClicked()
    }
    @objc func handleButtonActionTouchUpInside(_ sender: Any)
    {
        print("aaaa")
        // So we call the delete to response to the listener to handle logic
        let contact = ContactModel(name:"", phone:"" , email:"" , company:"" , website:"")
        contact.name = myTextFieldName.text!
        contact.phone = myTextFieldPhone.text!
        contact.email = myTextFieldEmail.text!
        contact.company = myTextFieldCompany.text!
        contact.website = myTextFieldWeb.text!
        
        
        delegate?.handleForMyButtonPressed(contact) // We use the "?" because if delegagte not setted in the listener, It mean nil value -> the protocol "handleForMyButtonPressed" will not be called.
    }
    @objc func keyboardWillShow(_ noti: Notification) -> Void {
        var kbHeight: CGFloat = 0
        if let info = noti.userInfo, let kbSize = (info[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            print("Keyboard will show with the keyboard size = {w: \(kbSize.width), h: \(kbSize.height)} in MyCustomView\n")
            kbHeight = kbSize.height
        } else {
            print("Keyboard will show in MyCustomView\n")
        }
        
        // Call the protocol which implemented in the listenter to handle logic
        delegate?.handleForKeyboardWillShow(kbHeight: kbHeight)
    }
    // Define the func to handle hide keyboard
    @objc func keyboardWillHide(_ noti: Notification) -> Void {
        print("Keyboard will hide in MyCustomView\n")
        
        // Call the protocol which implemented in the listenter to handle logic
        delegate?.handleForKeyboardWillHide()
    }
}




// We handle the UITextFieldDelegate to take the hide keyboard Action when User touch into the "Return" button of Keyboard
extension CustomView: UITextFieldDelegate
{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.delegate = self
        switch textField {
        case myTextFieldName:myTextFieldPhone.becomeFirstResponder()
        case myTextFieldPhone:myTextFieldEmail.becomeFirstResponder()
        case myTextFieldEmail:myTextFieldCompany.becomeFirstResponder()
        case myTextFieldCompany:myTextFieldWeb.becomeFirstResponder()
        default:
            textField.resignFirstResponder()
        }
        return false
    }
}
