//
//  ViewController.swift
//  AddcontactScreen
//
//  Created by Liem Pham on 12/19/18.
//  Copyright © 2018 Doodo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    setupViews()
    }
    
    
    lazy var  videoView : UIView = {
        let videoview = UIView()
        return videoview
    }()
    lazy var tableView:UITableView = {
        let tableview = UITableView()
        tableview.delegate = self
        tableview.dataSource = self
        
        tableview.register(CustomTitleCell.self, forCellReuseIdentifier: "titleCell")
        tableview.register(ChannelCell.self, forCellReuseIdentifier: "channelCell")
        return tableview
    }()
    func setupViews(){
        view.addSubview(videoView)
        view.addSubview(tableView)
        view.addConstraintsWithFormat("H:|-0-[v0]-0-|", views: videoView)
        view.addConstraintsWithFormat("H:|-8-[v0]-8-|", views: tableView)
        view.addConstraintsWithFormat("V:|-0-[v0(210)]", views: videoView)
        view.addConstraintsWithFormat("V:[v0]-0-[v1]-0-|", views:videoView, tableView)
        
    }
}






