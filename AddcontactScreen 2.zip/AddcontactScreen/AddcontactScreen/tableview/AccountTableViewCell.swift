//
//  AccountTableViewCell.swift
//  Lesson01
//
//  Created by Anh Tai LE on 21/12/2018.
//  Copyright © 2018 iZeta Co. All rights reserved.
//

import UIKit

class AccountTableViewCell: UITableViewCell {
    
    // The first, need define the custom cell key for reuseable purpose
    static let cellIdentifier = "AccountTableViewCellIdentifier"
    
    // Define some attributes of this cell
    lazy var avatarImageView: UIImageView = {
        return UIImageView()
    }()
    
    lazy var userNameLabel: UILabel = {
        return UILabel()
    }()
    
    lazy var subtitleLabel: UILabel = {
        return UILabel()
    }()
    
    fileprivate var layouted = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if !layouted {
            layouted = true
            handleLayout()
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        // Select the background for action when Cell is selected / not
        self.selectedBackgroundView?.backgroundColor = selected ? UIColor.yellow : .white
    }
    
    //! Handle layout UI
    fileprivate func handleLayout() {
        
        // Add left avatar image
        self.contentView.addSubview(avatarImageView)
        avatarImageView.translatesAutoresizingMaskIntoConstraints = false
        
        // Set attributes to make it like a circle -> we expect size of this image is (50, 50)
        avatarImageView.layer.cornerRadius = 25
        avatarImageView.layer.masksToBounds = true
        avatarImageView.contentMode = .scaleAspectFill
        avatarImageView.clipsToBounds = true
        
        // User Name
        self.contentView.addSubview(userNameLabel)
        userNameLabel.translatesAutoresizingMaskIntoConstraints = false
        userNameLabel.textColor = .black
        userNameLabel.textAlignment = .left
        userNameLabel.font = UIFont.boldSystemFont(ofSize: 22)
        
        // Sub title
        self.contentView.addSubview(subtitleLabel)
        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false
        subtitleLabel.textColor = .black
        subtitleLabel.textAlignment = .left
        subtitleLabel.font = UIFont.systemFont(ofSize: 16, weight: UIFont.Weight.light)
        
        // Make layout by VFL
        let views: [String : UIView] = ["avatar" : avatarImageView, "username" : userNameLabel, "subtitle" : subtitleLabel]
        let vAvatarConstraints = "V:|-10-[avatar(50)]"
        let hAvatarConstraints = "H:|-10-[avatar(50)]"
        let vInfoConstraints = "V:|-10-[username(30)]-0-[subtitle(20)]"
        let hUserNameConstraints = "H:[avatar]-10-[username]-10-|"
        let hSubtitleConstraints = "H:[avatar]-10-[subtitle]-10-|"
        
        var constraints: [NSLayoutConstraint] = []
        constraints += NSLayoutConstraint.constraints(withVisualFormat: vAvatarConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: nil, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: hAvatarConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: nil, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: vInfoConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: nil, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: hUserNameConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: nil, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: hSubtitleConstraints, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: nil, views: views)
        
        // Make it work
        NSLayoutConstraint.activate(constraints)
    }

}
