//
//  SettingsTableViewController.swift
//  Lesson01
//
//  Created by Anh Tai LE on 21/12/2018.
//  Copyright © 2018 iZeta Co. All rights reserved.
//

import UIKit
protocol  ContactTableViewControllerDelegate:NSObjectProtocol{
    func willSelectRowAt()->Void
}

class ContactTableViewController: UITableViewController {
    var delegate:ContactTableViewControllerDelegate?
    // Define the content of settings
    private var settingContents: [SettingGroupModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Register cell
        tableView.register(AccountTableViewCell.self, forCellReuseIdentifier: AccountTableViewCell.cellIdentifier)
        tableView.register(NumBadgeTableViewCell.self, forCellReuseIdentifier: NumBadgeTableViewCell.cellIdentifier)
        tableView.delegate = self
        tableView.dataSource = self
        // Generate content
        generateContent()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    private func generateContent() {
        
        let accountGroup: SettingGroupModel = SettingGroupModel()
        accountGroup.title = ""
        accountGroup.items.append(SettingItem.init(title: "Your Self", subTitle: "Name, Phone number , Address, your label", imgName: "defaultAvatar", numBadge: 0, type: .account, rightAction: ""))
        settingContents.append(accountGroup)
        
        
        let connectionGroup: SettingGroupModel = SettingGroupModel()
        connectionGroup.title = "Close Friends"
        connectionGroup.items.append(SettingItem.init(title: "Add contact", subTitle: "", imgName: "", numBadge: 0, type: .functionality, rightAction: ""))
        connectionGroup.items.append(SettingItem.init(title: "Annieeee", subTitle: "", imgName: "defaultAvatar", numBadge: 0, type: .functionality, rightAction: ""))
        connectionGroup.items.append(SettingItem.init(title: "Booollieeeee", subTitle: "", imgName: "defaultAvatar", numBadge: 0, type: .functionality, rightAction: ""))
        connectionGroup.items.append(SettingItem.init(title: "Caitlieeeee", subTitle: "Cathieeee", imgName: "defaultAvatar", numBadge: 0, type: .functionality, rightAction: ""))
        connectionGroup.items.append(SettingItem.init(title: "Doggieeeee", subTitle: "", imgName: "defaultAvatar", numBadge: 0, type: .functionality, rightAction: ""))
        connectionGroup.items.append(SettingItem.init(title: "Evieeeeeee", subTitle: "", imgName: "defaultAvatar", numBadge: 0, type: .functionality, rightAction: ""))
        settingContents.append(connectionGroup)
        
        // Make it work
        self.tableView.reloadData()
    }
    
    
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return settingContents.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return settingContents[section].items.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Get the section data
        let settingGroup = settingContents[indexPath.section]
        let settingItem = settingGroup.items[indexPath.row]
        
        // Check to draw right cell type
        if settingItem.type == .account {
            if let cell: AccountTableViewCell = tableView.dequeueReusableCell(withIdentifier: AccountTableViewCell.cellIdentifier, for: indexPath) as? AccountTableViewCell {
                
                cell.avatarImageView.image = UIImage(named: settingItem.imgName)
                cell.userNameLabel.text = settingItem.title
                cell.subtitleLabel.text = settingItem.subtitle
            
                return cell
            }
        } else if settingItem.type == .updateInfo {
            if let cell: NumBadgeTableViewCell = tableView.dequeueReusableCell(withIdentifier: NumBadgeTableViewCell.cellIdentifier, for: indexPath) as? NumBadgeTableViewCell {
                
                cell.titleLabel.text = settingItem.title
                cell.badgeLabel.text = "\(settingItem.numBadge)"
                
                return cell
            }
        } else if settingItem.type == .functionality { // -> This is default table view cell
            var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "FunctionalityWithDefaultStyleDetail")
            if cell == nil {
                cell = UITableViewCell.init(style: UITableViewCell.CellStyle.default, reuseIdentifier: "FunctionalityWithDefaultStyleDetail")
            }
            
            cell!.accessoryType = .disclosureIndicator
            cell!.textLabel?.text = settingItem.title
            cell!.detailTextLabel?.text = settingItem.subtitle
            cell!.imageView?.contentMode = .scaleAspectFit
            cell!.imageView?.image = UIImage(named: settingItem.imgName)?.withAlignmentRectInsets(UIEdgeInsets(top: -10, left: -20, bottom: -10, right: -20))
            
            return cell!
        } else if settingItem.type == .switchAction {
            var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "FunctionalityWithDefaultStyleSwitch")
            if cell == nil {
                cell = UITableViewCell.init(style: UITableViewCell.CellStyle.default, reuseIdentifier: "FunctionalityWithDefaultStyleSwitch")
            }
            
            cell!.accessoryView = UISwitch()
            cell!.textLabel?.text = settingItem.title
            cell!.detailTextLabel?.text = settingItem.subtitle
            cell!.imageView?.contentMode = .scaleAspectFit
            cell!.imageView?.image = UIImage(named: settingItem.imgName)
            cell!.imageView?.transform = CGAffineTransform.init(scaleX: 0.5, y: 0.5)
            
            return cell!
        }
        
        // In exception case, return the default table view cell for sure not crash app
        var cell: UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        if cell == nil {
            cell = UITableViewCell.init(style: UITableViewCell.CellStyle.default, reuseIdentifier: "reuseIdentifier")
        }
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // Define the height of cell
        let settingGroup = settingContents[indexPath.section]
        let settingItem = settingGroup.items[indexPath.row]
        
        if settingItem.type == .account {
            return 70
        }
        
        return 50
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return settingContents[section].title
    }
    override func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        let scrollVC = MyScrollViewController()
        self.present(scrollVC, animated: true, completion: nil)
        return nil

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
     
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
}
