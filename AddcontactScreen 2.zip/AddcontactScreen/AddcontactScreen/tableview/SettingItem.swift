//
//  SettingItem.swift
//  Lesson01
//
//  Created by Anh Tai LE on 21/12/2018.
//  Copyright © 2018 iZeta Co. All rights reserved.
//

import UIKit

enum SettingType: Int {
    case account = 0, updateInfo, functionality, switchAction
}

class SettingItem: NSObject {
    
    // Define some attributes
    var title = ""
    
    var subtitle = ""
    
    var imgName = ""
    
    var numBadge = 0
    
    var type: SettingType = .account
    
    var rightAction = ""
    
    convenience init(title: String, subTitle: String, imgName: String, numBadge: Int, type: SettingType, rightAction: String) {
        self.init()
        
        
        self.title = title
        self.subtitle = subTitle
        self.imgName = imgName
        self.numBadge = numBadge
        self.type = type
        self.rightAction = rightAction
    }
    
}
