//
//  NumBadgeTableViewCell.swift
//  Lesson01
//
//  Created by Anh Tai LE on 21/12/2018.
//  Copyright © 2018 iZeta Co. All rights reserved.
//

import UIKit

class NumBadgeTableViewCell: UITableViewCell {
    
    static let cellIdentifier = "NumBadgeTableViewCellIdentifier"
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        
        label.backgroundColor = .clear
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 18)
        label.textAlignment = .left
        
        return label
    }()
    
    lazy var badgeLabel: UILabel = {
        let label = UILabel()
        
        label.backgroundColor = .red
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 14)
        label.textAlignment = .center
        label.layer.cornerRadius = 12
        label.layer.masksToBounds = true
        label.clipsToBounds = true
        
        return label
    }()
    
    fileprivate var layouted = false

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        // Select the background for action when Cell is selected / not
        self.selectedBackgroundView?.backgroundColor = selected ? UIColor.yellow : .white
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if !layouted {
            layouted = true
            handleLayout()
        }
    }

    private func handleLayout() {
        
        self.contentView.addSubview(titleLabel)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        
        self.contentView.addSubview(badgeLabel)
        badgeLabel.translatesAutoresizingMaskIntoConstraints = false
        
        // Layout it
        let views: [String : UIView] = ["title" : titleLabel, "badge" : badgeLabel]
        let hConstraintVFL = "H:|-20-[title]-10-[badge(24)]-10-|"
        let vTitleConstraintVFL = "V:|-10-[title(24)]"
        let vBadgeConstraintVFL = "V:|-10-[badge(24)]"
        
        var constraints: [NSLayoutConstraint] = []
        constraints += NSLayoutConstraint.constraints(withVisualFormat: hConstraintVFL, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: nil, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: vTitleConstraintVFL, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: nil, views: views)
        constraints += NSLayoutConstraint.constraints(withVisualFormat: vBadgeConstraintVFL, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: nil, views: views)
        
        NSLayoutConstraint.activate(constraints)
    }
    
}
