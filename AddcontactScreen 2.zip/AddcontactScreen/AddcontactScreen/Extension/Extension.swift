//
//  Extension.swift
//  AddcontactScreen
//
//  Created by Liem Pham on 5/16/19.
//  Copyright © 2019 Doodo. All rights reserved.
//

import UIKit
extension UIView{
    func addConstraintsWithFormat(_ format: String, views: UIView...) {
        var viewsDictionary = [String: UIView]()
        for (index, view) in views.enumerated() {
            let key = "v\(index)"
            view.translatesAutoresizingMaskIntoConstraints = false
            viewsDictionary[key] = view
        }
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: format, options: NSLayoutConstraint.FormatOptions(), metrics: nil, views: viewsDictionary))
    }
}


extension ViewController : UITableViewDelegate , UITableViewDataSource {
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let customTitleCell = tableView.dequeueReusableCell(withIdentifier: "titleCell", for: indexPath) as! CustomTitleCell
            customTitleCell.videoTitle.text = "Taylor Swift - I knew you were a trouble"
        
            customTitleCell.numberofViews.text = "145.3M views"
        
            return customTitleCell
            
        } else {
            let channelCell = tableView.dequeueReusableCell(withIdentifier: "channelCell", for: indexPath) as! ChannelCell
            return channelCell
        }
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0{
        return 150
        } else {
            return 50
        }
    }
    
   
    
    
}
