//
//  MyScrollViewController.swift
//  Lesson01
//
//  Created by Anh Tai LE on 20/12/2018.
//  Copyright © 2018 iZeta Co. All rights reserved.
//

import UIKit
protocol MyScrollViewControllerDelegate : NSObjectProtocol {
    func handleForMyButtonTapped(contact:ContactModel)
}

class MyScrollViewController: UIViewController {
    var delegate:MyScrollViewControllerDelegate?
    // MARK: We define all attributes here
    
    
    let scrollView: UIScrollView = {
       return  UIScrollView()
    }()
    
    let contentView: UIView = {
        return UIView()
    }()
    
    let contactView: CustomView = {
        return CustomView()
    }()
    
    // We use it to handle for keyboard show / hide
    var bottomConstraint: NSLayoutConstraint?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.view.backgroundColor = UIColor.init(red: 1.0, green: 105.0/255.0, blue: 180.0/255.0, alpha: 1.0)
        // Do any additional setup after loading the view.
        layoutUI()
        setupnavigationbar()
        // Setup delegate
        contactView.delegate = self
        
    }
    func setupnavigationbar(){
        self.title = "add contact"
        
        let addbutton = UIButton()
        addbutton.setTitle("Done", for: .normal)
        addbutton.titleLabel?.textAlignment = .center
        addbutton.titleLabel?.textColor = .black
        addbutton.addTarget(self, action: #selector(handleForMyButtonPressed(_:)), for: .touchUpInside)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: addbutton)
    }
    
    // MARK: We layout UI here
    fileprivate func layoutUI() {
        
        // Here is example for non pass value
        // In case UIScrollView, we need to manual setup bottom constraint to handle show / hide keyboard. Otherwise don't need
        self.autoLayout(view: scrollView, parent: view, contentInset: UIEdgeInsets.zero, width: nil, height: nil, isEqualWidth: false, isEqualHeight: false, isMixInsetWidthHeight: false, dontSetBottomConstraint: true)
        // So we need to setup bottom layout between UIScroll view with Its super view (UIView of UIControllerView)
        // In default, we set constant of bottom is 0 to make it's equal height with super view
        bottomConstraint = NSLayoutConstraint.init(item: self.view, attribute: NSLayoutConstraint.Attribute.bottom, relatedBy: NSLayoutConstraint.Relation.equal, toItem: self.scrollView, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1.0, constant: 0)
        NSLayoutConstraint.activate([bottomConstraint!])
        //setup scrollview
        self.autoLayout(view: contentView, parent: scrollView, contentInset: UIEdgeInsets.zero, width: nil, height: 1600, isEqualWidth: true, isEqualHeight: false, isMixInsetWidthHeight: true)
        contentView.backgroundColor = UIColor.lightGray
        self.autoLayout(view: contactView, parent: contentView, contentInset: UIEdgeInsets.zero, isEqualWidth: true , isEqualHeight: true)
        
    }

    // Write a reuseable function to layout
    // width: CGFloat? = nil, height: CGFloat? = nil => It's mean in the case we not pass value into params, value default is nil
    fileprivate func autoLayout(view: UIView, parent: UIView, contentInset: UIEdgeInsets, width: CGFloat? = 10 , height: CGFloat? = 10,
                                isEqualWidth: Bool = false, isEqualHeight: Bool = false, isMixInsetWidthHeight: Bool = false,
                                dontSetBottomConstraint: Bool = false) {
        
        // The first need to add subview before auto layout subview related to parent view, otherwise it's fail
        parent.addSubview(view)
        view.translatesAutoresizingMaskIntoConstraints = false
        
        // Second define some value for views & metrics to setup VFL
        let views: [String : UIView] = ["myView" : view, "superView" : parent]
        var metrics: [String : CGFloat] = ["top" : contentInset.top,
                                           "bottom" : contentInset.bottom,
                                           "right" : contentInset.right,
                                           "left" : contentInset.left]
        // Set width if have
        if let widthValue = width {
            metrics["width"] = widthValue
        }
        
        // Set height if have
        if let heightValue = height {
            metrics["height"] = heightValue
        }
        
        // Create VFL String
        var vflVertical: String = "V:|-top-[myView]-bottom-|"
        if isEqualHeight {
            if dontSetBottomConstraint {
                vflVertical = "V:|-top-[myView(==superView)]"
            } else {
                vflVertical = "V:|-top-[myView(==superView)]-bottom-|"
            }
        } else {
            if let _ = height {
                if !isMixInsetWidthHeight || dontSetBottomConstraint {
                    vflVertical = "V:|-top-[myView(height)]"
                } else {
                    vflVertical = "V:|-top-[myView(height)]-bottom-|"
                }
            } else if dontSetBottomConstraint {
                vflVertical = "V:|-top-[myView]"
            }
        }
        
        var vflHorizontal: String = "H:|-left-[myView]-right-|"
        if isEqualWidth {
            vflHorizontal = "H:|-left-[myView(==superView)]-right-|"
        } else {
            if let _ = width {
                if isMixInsetWidthHeight {
                    vflHorizontal = "H:|-left-[myView(width)]-right-|"
                } else {
                    vflHorizontal = "H:|-left-[myView(width)]"
                }
            }
        }
        
        // Create Autolayout Constraints
        let hConstraints = NSLayoutConstraint.constraints(withVisualFormat: vflHorizontal, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
        let vConstraints = NSLayoutConstraint.constraints(withVisualFormat: vflVertical, options: NSLayoutConstraint.FormatOptions.init(rawValue: 0), metrics: metrics, views: views)
        
        // Make it work
        NSLayoutConstraint.activate(vConstraints + hConstraints)
    }
}

// Extension to handle MyCustomViewDelegate
extension MyScrollViewController: CustomViewDelegate {
    func handleForMyButtonClicked() {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func handleForMyButtonPressed(_ contact: ContactModel) {
        delegate?.handleForMyButtonTapped(contact: contact)
        print("uaaaaa")
        navigationController?.popViewController(animated: true)
        //let message = "Name: \(contact.name!)"
        
        //let alert = UIAlertController(title: "add new contact", message: message, preferredStyle: UIAlertController.Style.alert)
        // add an action (button)
        //alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler:nil))
        
        // show the alert
       /////self.present(alert, animated: false, completion: nil)
        
    }
    
    func handleForKeyboardWillShow(kbHeight: CGFloat) {
        bottomConstraint?.constant = kbHeight
        NSLayoutConstraint.activate([bottomConstraint!])
    }
    
    func handleForKeyboardWillHide() {
        bottomConstraint?.constant = 0
        NSLayoutConstraint.activate([bottomConstraint!])
    }
    
   }

